<?php
defined('_JEXE') or die;
echo '<h2>Hello World</h2>';